import Constants from 'expo-constants';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { api } from './api';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }),
});

/**
 * Demande l'autorisation, récupère le jeton Expo Push et l'enregistre sur le backend.
 * Nécessite un appareil physique et un build de développement / TestFlight (pas d'Expo Go pour le push iOS).
 */
export async function registerForPush(): Promise<{ ok: boolean; message: string }> {
  if (!Device.isDevice) return { ok: false, message: 'Les notifications push nécessitent un iPhone physique.' };
  const { status: existing } = await Notifications.getPermissionsAsync();
  let status = existing;
  if (existing !== 'granted') status = (await Notifications.requestPermissionsAsync()).status;
  if (status !== 'granted') return { ok: false, message: 'Autorisation refusée dans Réglages iOS.' };
  const projectId = Constants?.expoConfig?.extra?.eas?.projectId ?? Constants?.easConfig?.projectId;
  if (!projectId) return { ok: false, message: 'projectId EAS absent : lance « npx eas-cli init » (voir README).' };
  try {
    const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
    await api('/api/devices', { method: 'POST', body: { expoToken: token, platform: Platform.OS } });
    return { ok: true, message: 'Notifications activées sur cet iPhone.' };
  } catch (e: any) {
    return { ok: false, message: `Échec de l’enregistrement : ${e.message}` };
  }
}
