import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Connexion au backend Crypto Radar.
 * L'URL et la clé d'application sont saisies dans Réglages et stockées dans le trousseau iOS (SecureStore) :
 * aucune clé n'est écrite dans le code de l'app. Les clés des fournisseurs de données restent sur le serveur.
 */
const K_URL = 'radar.apiUrl';
const K_KEY = 'radar.appKey';

let mem: { url: string; key: string } | null = null;
const listeners = new Set<() => void>();

export async function getConnection() {
  if (mem) return mem;
  const [url, key] = await Promise.all([SecureStore.getItemAsync(K_URL), SecureStore.getItemAsync(K_KEY)]);
  mem = { url: url ?? '', key: key ?? '' };
  return mem;
}
export async function setConnection(url: string, key: string) {
  const clean = url.trim().replace(/\/+$/, '');
  await SecureStore.setItemAsync(K_URL, clean);
  await SecureStore.setItemAsync(K_KEY, key.trim());
  mem = { url: clean, key: key.trim() };
  listeners.forEach((l) => l());
}
export function onConnectionChange(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export class ApiError extends Error {
  constructor(message: string, public status?: number) { super(message); }
}

export async function api<T = any>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const { url, key } = await getConnection();
  if (!url) throw new ApiError('Serveur non configuré : ouvre Réglages.', 0);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 20000);
  try {
    const res = await fetch(`${url}${path}`, {
      method: init.method ?? 'GET',
      headers: { 'x-app-key': key, ...(init.body ? { 'content-type': 'application/json' } : {}) },
      body: init.body ? JSON.stringify(init.body) : undefined,
      signal: ctrl.signal,
    });
    const text = await res.text();
    const data = text ? JSON.parse(text) : null;
    if (!res.ok) throw new ApiError(data?.error ?? `Erreur ${res.status}`, res.status);
    return data as T;
  } catch (e: any) {
    if (e instanceof ApiError) throw e;
    throw new ApiError(e?.name === 'AbortError' ? 'Le serveur ne répond pas.' : 'Serveur injoignable.', 0);
  } finally {
    clearTimeout(timer);
  }
}

type State<T> = { data: T | null; error: string | null; loading: boolean; refreshing: boolean; fromCache: boolean; cachedAt: string | null; status?: number };

/**
 * Charge une ressource ; en cas d'échec réseau, affiche la dernière version en cache (avec sa date).
 * L'app reste ainsi utilisable si le serveur ou un fournisseur est temporairement indisponible.
 */
export function useApi<T = any>(path: string | null, deps: unknown[] = []) {
  const [st, setSt] = useState<State<T>>({ data: null, error: null, loading: true, refreshing: false, fromCache: false, cachedAt: null });
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  const load = useCallback(async (isRefresh = false) => {
    if (!path) return;
    setSt((s) => ({ ...s, loading: !isRefresh && !s.data, refreshing: isRefresh }));
    const cacheKey = `cache:${path}`;
    try {
      const data = await api<T>(path);
      if (!alive.current) return;
      setSt({ data, error: null, loading: false, refreshing: false, fromCache: false, cachedAt: null });
      AsyncStorage.setItem(cacheKey, JSON.stringify({ at: new Date().toISOString(), data })).catch(() => undefined);
    } catch (e: any) {
      let cached: { at: string; data: T } | null = null;
      try { const raw = await AsyncStorage.getItem(cacheKey); cached = raw ? JSON.parse(raw) : null; } catch { /* ignore */ }
      if (!alive.current) return;
      setSt((s) => ({
        data: cached?.data ?? s.data, error: e.message, loading: false, refreshing: false,
        fromCache: !!cached, cachedAt: cached?.at ?? null, status: e.status,
      }));
    }
  }, [path, ...deps]);

  useEffect(() => { load(); return onConnectionChange(() => load()); }, [load]);
  return { ...st, reload: () => load(true) };
}
