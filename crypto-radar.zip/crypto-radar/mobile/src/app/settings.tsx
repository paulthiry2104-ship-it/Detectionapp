import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, Text, TextInput, View } from 'react-native';
import { Screen } from '../components/Screen';
import { Button, Card, Chip, Row, Section } from '../components/ui';
import { api, getConnection, setConnection, useApi } from '../lib/api';
import { registerForPush } from '../lib/push';
import { C, R, S, T } from '../lib/theme';

const COMPONENT_KEYS = ['volumeAccel', 'liquidityGrowth', 'onchain', 'community', 'narrative', 'catalyst', 'headroom', 'tokenomics'] as const;
const LABELS: Record<string, string> = { volumeAccel: 'Volume', liquidityGrowth: 'Liquidité', onchain: 'On-chain', community: 'Communauté', narrative: 'Narrative', catalyst: 'Catalyseur', headroom: 'Marge', tokenomics: 'Tokenomics' };

export default function Settings() {
  const router = useRouter();
  const [url, setUrl] = useState('');
  const [key, setKey] = useState('');
  const [test, setTest] = useState<string | null>(null);
  const settings = useApi<any>('/api/settings');
  const [hz, setHz] = useState<'week' | 'month' | 'year'>('week');

  useEffect(() => { getConnection().then((c) => { setUrl(c.url); setKey(c.key); }); }, []);

  const save = async () => {
    await setConnection(url, key);
    try {
      const st = await api('/api/status');
      setTest(`✓ Connecté · ${st.tokensTracked} tokens suivis · ${st.warnings.length} avertissement(s)`);
    } catch (e: any) { setTest(`✗ ${e.message}`); }
  };

  const notify = settings.data?.notify;
  const weights = settings.data?.weights;
  const setNotify = async (patch: any) => { await api('/api/settings/notify', { method: 'PUT', body: patch }); settings.reload(); };
  const bump = async (k: string, delta: number) => {
    const v = Math.max(0, Math.min(1, Math.round(((weights[hz][k] ?? 0) + delta) * 100) / 100));
    await api('/api/settings/weights', { method: 'PUT', body: { [hz]: { [k]: v } } });
    settings.reload();
  };

  return (
    <Screen>
      <Section title="Serveur">
        <Card>
          <Text style={T.tiny}>Adresse du backend (ex. https://crypto-radar-pablo.fly.dev)</Text>
          <TextInput value={url} onChangeText={setUrl} autoCapitalize="none" autoCorrect={false} keyboardType="url" placeholder="https://…" placeholderTextColor={C.dim} style={inp} />
          <Text style={T.tiny}>Clé d’application (APP_API_KEY du serveur) — stockée dans le trousseau iOS</Text>
          <TextInput value={key} onChangeText={setKey} autoCapitalize="none" autoCorrect={false} secureTextEntry placeholder="clé" placeholderTextColor={C.dim} style={inp} />
          <Button title="Enregistrer et tester" icon="checkmark" onPress={save} />
          {test ? <Text style={[T.sub, { marginTop: S.s, color: test.startsWith('✓') ? C.up : C.down }]}>{test}</Text> : null}
        </Card>
      </Section>

      <Section title="Notifications">
        <Card>
          <Button kind="ghost" icon="notifications" title="Activer les notifications push" onPress={async () => { const r = await registerForPush(); Alert.alert(r.ok ? 'OK' : 'Impossible', r.message); }} />
          {notify ? (
            <>
              <Text style={[T.tiny, { marginTop: S.m, marginBottom: 6 }]}>Fréquence</Text>
              <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
                <Chip label="Instantané" on={notify.mode === 'instant'} onPress={() => setNotify({ mode: 'instant' })} />
                <Chip label="Résumé groupé" on={notify.mode === 'digest'} onPress={() => setNotify({ mode: 'digest' })} />
                <Chip label="Rapport du jour seulement" on={notify.mode === 'daily_only'} onPress={() => setNotify({ mode: 'daily_only' })} />
              </View>
              {notify.mode === 'digest' ? (
                <View style={{ flexDirection: 'row', gap: 6, marginTop: 8 }}>
                  {[30, 60, 180, 360].map((m) => <Chip key={m} label={`${m >= 60 ? m / 60 + ' h' : m + ' min'}`} on={notify.digestMinutes === m} onPress={() => setNotify({ digestMinutes: m })} />)}
                </View>
              ) : null}
              <Row label="Heures calmes (Paris)" value={`${notify.quietStart} h → ${notify.quietEnd} h`} />
              <View style={{ flexDirection: 'row', gap: 6, marginTop: 6 }}>
                <Chip label="22 h–7 h" on={notify.quietStart === 22 && notify.quietEnd === 7} onPress={() => setNotify({ quietStart: 22, quietEnd: 7 })} />
                <Chip label="23 h–7 h" on={notify.quietStart === 23 && notify.quietEnd === 7} onPress={() => setNotify({ quietStart: 23, quietEnd: 7 })} />
                <Chip label="Aucune" on={notify.quietStart === notify.quietEnd} onPress={() => setNotify({ quietStart: 0, quietEnd: 0 })} />
              </View>
            </>
          ) : <Text style={[T.tiny, { marginTop: 8 }]}>Connecte le serveur pour régler la fréquence.</Text>}
        </Card>
      </Section>

      {weights ? (
        <Section title="Pondérations du score">
          <Card>
            <View style={{ flexDirection: 'row', gap: 6, marginBottom: S.s }}>
              {(['week', 'month', 'year'] as const).map((k) => <Chip key={k} label={{ week: '7 j', month: '30 j', year: '12 mois' }[k]} on={hz === k} onPress={() => setHz(k)} />)}
            </View>
            {COMPONENT_KEYS.map((k) => (
              <View key={k} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6 }}>
                <Text style={[T.sub, { flex: 1 }]}>{LABELS[k]}</Text>
                <Chip label="−" onPress={() => bump(k, -0.05)} />
                <Text style={[T.num, { width: 48, textAlign: 'center' }]}>{Math.round((weights[hz][k] ?? 0) * 100)}</Text>
                <Chip label="+" onPress={() => bump(k, 0.05)} />
              </View>
            ))}
            <Text style={[T.tiny, { marginVertical: S.s }]}>Les poids sont normalisés. Appliqués à la prochaine analyse ; l’historique garde la version utilisée.</Text>
            <Button kind="ghost" title="Rétablir les valeurs par défaut" onPress={async () => { await api('/api/settings/weights', { method: 'PUT', body: { reset: true } }); settings.reload(); }} />
          </Card>
        </Section>
      ) : null}

      <Section title="Plus">
        <View style={{ gap: S.s }}>
          <Button kind="ghost" icon="newspaper-outline" title="Rapport du jour" onPress={() => router.push('/report')} />
          <Button kind="ghost" icon="time-outline" title="Historique et performances" onPress={() => router.push('/history')} />
          <Button kind="ghost" icon="book-outline" title="Sources et méthodologie" onPress={() => router.push('/methodology')} />
        </View>
      </Section>
    </Screen>
  );
}

const inp = { color: C.text, backgroundColor: C.surface2, borderRadius: R.m, padding: 11, marginTop: 4, marginBottom: S.m, fontSize: 15 } as const;
