# Crypto Radar

App iPhone (Expo / React Native) + backend Node.js qui analyse le marché crypto **tous les jours à 06 h (Paris)**, même quand ton iPhone est éteint, et classe les projets sur trois horizons : **cette semaine**, **le mois prochain**, **durant l’année**.

> Rien ici n’est un conseil en investissement. Les scores et scénarios sont des estimations d’un modèle, jamais des promesses ni des probabilités.

```
crypto-radar/
├── backend/   Node 22 + TypeScript · Fastify · SQLite (node:sqlite) · node-cron
│   ├── src/providers/   CoinGecko, DexScreener, GeckoTerminal, GoPlus, RugCheck, CoinMarketCal
│   ├── src/engine/      variables point-in-time, score, scénarios, détection des suspects
│   ├── src/jobs/        analyse quotidienne, rafraîchissement, détection, rapport du jour
│   ├── src/notify/      règles d’alerte, anti-aberrations, push Expo
│   ├── src/backtest/    performances passées (avec tokens disparus)
│   └── test/            19 tests (dont l’analyse quotidienne de bout en bout)
├── mobile/    Expo SDK 58 · expo-router · 8 écrans + rapport du jour
└── .github/workflows/   CI + surveillance externe de l’analyse quotidienne
```

---

## 1. Ce qui fonctionne réellement, ce qui demande une clé, ce qui manque

| Fonction | État |
|---|---|
| Analyse quotidienne 06 h Paris (heure d’été/hiver gérée), verrou anti-doublon, rattrapage au redémarrage | ✅ testée |
| Actualisation prix/volumes/liquidités toutes les 3 h, détection nouveaux pools toutes les 20 min | ✅ |
| Échec honnête : statut `failed`, aucun rapport, anciennes données conservées avec leur date, notification d’échec | ✅ testé |
| Panne d’une seule source → analyse `partial` + avertissement | ✅ testé |
| Coupe-circuit par fournisseur (une API en panne ne bloque pas l’analyse) | ✅ testé |
| Score /100 par horizon, confiance séparée, « Données insuffisantes » au lieu d’un score fabriqué | ✅ |
| Scénarios prudent / haussier / exceptionnel par comparables, fourchette FDV → capitalisation | ✅ |
| Détection honeypot, taxes, faux contrats, liquidité nulle, volume artificiel, concentration | ✅ (GoPlus EVM, RugCheck Solana) |
| Historique horodaté des classements + mouvements expliqués + sorties de liste | ✅ |
| Performances passées incluant les tokens disparus, comparées au Bitcoin | ✅ (résultats après 7 / 30 / 365 jours d’historique) |
| Rapport du jour | ✅ |
| Favoris, alertes prix / volume / entrée en liste / catalyseur, fréquence, heures calmes | ✅ |
| Push iPhone | ✅ code prêt — **nécessite un build EAS + compte Apple Developer** (pas dans Expo Go) |
| CoinGecko | fonctionne sans clé, **clé Demo gratuite fortement conseillée** |
| Catalyseurs datés automatiques | **clé CoinMarketCal** (sinon : ajout manuel avec source obligatoire) |
| Réseaux sociaux / recherches Google | ❌ non intégré (API X payante) — affiché « Non intégré » |
| Calendriers de déblocage (unlocks), revenus de protocole | ❌ non intégré — la borne basse des multiplicateurs utilise la FDV |

**Vérifié ici :** 19 tests backend passent, typecheck backend + mobile OK, le bundle iOS compile (`expo export`), et un lancement réel du serveur sans accès réseau échoue proprement (« Aucune donnée de marché récupérée »).
**Pas vérifié ici :** les appels aux vraies API (mon environnement les bloque) et le rendu sur iPhone. Lance `npm run smoke` (étape 3) pour valider les sources réelles en 30 secondes.

---

## 2. Variables d’environnement (backend)

Copie `backend/.env.example` en `backend/.env`. Obligatoires :

| Variable | Rôle |
|---|---|
| `APP_API_KEY` | clé que l’app envoie (`x-app-key`). `openssl rand -hex 24` |
| `INTERNAL_JOB_SECRET` | protège `/internal/*` (déclenchement manuel, GitHub). `openssl rand -hex 32` |
| `DATABASE_PATH` | fichier SQLite sur **disque persistant** (`/data/radar.db` en prod) |

Recommandées : `COINGECKO_API_KEY` (Demo gratuite sur coingecko.com/en/api), `COINMARKETCAL_API_KEY`.
Planification : `DAILY_CRON=0 6 * * *`, `TZ_SCHEDULE=Europe/Paris`, `REFRESH_CRON`, `DISCOVERY_CRON`.
Aucune de ces valeurs ne va dans l’app mobile.

---

## 3. Lancer le backend en local

```bash
cd backend
npm install
cp .env.example .env      # puis remplis APP_API_KEY et INTERNAL_JOB_SECRET
npm run smoke             # vérifie chaque vraie source de données
npm test                  # 19 tests
npm run job:daily         # lance une analyse complète maintenant (code de sortie 1 si échec)
npm start                 # serveur + planificateur sur http://localhost:8080
```

Une analyse complète prend ~5–10 min (on respecte les limites des API gratuites).

---

## 4. Déployer en production (Fly.io, région Paris)

Le planificateur tourne **dans le serveur** : il faut une machine toujours allumée + un volume persistant.

```bash
brew install flyctl && fly auth login
cd backend
fly launch --no-deploy --copy-config      # garde fly.toml, change le nom de l’app si besoin
fly volumes create radar_data --region cdg --size 1
fly secrets set APP_API_KEY=$(openssl rand -hex 24) INTERNAL_JOB_SECRET=$(openssl rand -hex 32) COINGECKO_API_KEY=ta_cle
fly deploy
fly secrets list                           # (les valeurs ne sont pas réaffichées : note-les avant)
```

Coût indicatif : ~2–5 $/mois (shared-cpu-1x, 512 Mo, 1 Go de volume). Alternative : Railway avec le même `Dockerfile` et un volume monté sur `/data`.

**Première analyse** (sans attendre 06 h) :
```bash
curl -X POST "https://TON-APP.fly.dev/internal/jobs/daily/run?wait=1" -H "x-internal-secret: TON_SECRET"
```

### Surveillance externe (GitHub Actions)

Pousse le dossier sur un repo GitHub, puis dans *Settings → Secrets → Actions* ajoute :
`RADAR_API_URL` (ex. `https://ton-app.fly.dev`) et `INTERNAL_JOB_SECRET`.
Le workflow `daily-watchdog.yml` passe à 06 h 35 : il relance l’analyse si elle manque, et **échoue (e-mail GitHub)** si aucune analyse n’a réussi depuis 26 h.

### Prouver que la tâche quotidienne tourne

```bash
curl https://TON-APP.fly.dev/health                 # lastDailySuccess = date de la dernière réussite
curl -H "x-app-key: CLE" https://TON-APP.fly.dev/api/history/runs   # chaque exécution, statut, étapes, erreurs
fly logs                                             # "début de tâche" / "fin de tâche" à 06:00
```
Dans l’app : **Paramètres → Historique et performances** liste chaque analyse (succès / partielle / échec).

---

## 5. Installer l’app sur ton iPhone

### Option A — tout de suite, gratuit (Expo Go)
1. Installe **Expo Go** depuis l’App Store.
2. Sur ton Mac/PC :
   ```bash
   cd mobile
   npm install
   npx expo start --tunnel
   ```
3. Scanne le QR code avec l’appareil photo de l’iPhone.
4. Dans l’app : **Paramètres** (roue dentée) → adresse du serveur + `APP_API_KEY` → *Enregistrer et tester*.

Tout marche sauf le **push** (Expo Go ne le gère pas sur iOS) : les alertes restent visibles dans l’onglet Alertes.

### Option B — app installée + notifications push (compte Apple Developer, 99 $/an)
```bash
cd mobile
npx eas-cli@latest login
npx eas-cli@latest init                       # remplit extra.eas.projectId dans app.json
npx eas-cli@latest device:create              # enregistre ton iPhone (lien à ouvrir sur le téléphone)
npx eas-cli@latest build --profile preview --platform ios
```
Installe le build via le lien/QR fourni, ouvre l’app → Paramètres → *Activer les notifications push*.
Pour TestFlight : `eas build --profile production --platform ios` puis `eas submit -p ios`.

---

## 6. Méthode (résumé — détail dans l’app : Sources et méthodologie)

- **Horizons** : fenêtres `[maintenant, +7 j]`, `[+30 j]`, `[+365 j]` recalculées à chaque analyse.
- **Score /100** = moyenne pondérée des critères disponibles (volume vs son propre historique, liquidité sur 3 j, transactions/activité dev, détenteurs, narrative CoinGecko, catalyseur dans la fenêtre, marge par comparables, part en circulation) × (1 − risque de manipulation) × (1 − pénalité « déjà monté ») × fiabilité. Poids modifiables dans l’app.
- **Confiance** (séparée) : fraîcheur, nombre de sources, recoupement des prix, complétude, profondeur d’historique.
- **Multiplicateurs** : position du token parmi les projets de sa catégorie, cible = +N points de percentile (7 j : +5/+15/+30 ; 30 j : +10/+25/+45 ; 12 mois : +15/+35/+60). Fourchette = cible ÷ FDV → cible ÷ capitalisation. Rien si < 8 comparables ou aucune cible défendable. Ces sauts sont des hypothèses à recalibrer avec la page Performances.
- **Backtest honnête** : chaque calcul n’utilise que les données enregistrées avant sa date ; les tokens disparus comptent.
- Les « boosts » DexScreener sont des pubs payantes : jamais un signal positif.

## 7. Prochaines améliorations utiles
1. Calibrer les poids et les sauts de percentile sur 30+ jours d’historique réel (page Performances, `/internal/replay`).
2. Ajouter une source d’unlocks (ex. Tokenomist, payante) pour remplacer l’hypothèse FDV.
3. Données sociales (LunarCrush ou API X) pour le critère communauté.
